class UnsafePortError(Exception):
    pass